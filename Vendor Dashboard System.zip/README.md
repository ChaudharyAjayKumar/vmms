
  # Vendor Dashboard System

  This is a code bundle for Vendor Dashboard System. The original project is available at https://www.figma.com/design/q10irGXZiS0WdAiPjMelBR/Vendor-Dashboard-System.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  